const cognitronInputElementID = '#input-cognitronchat'
const cognitronContentElementID = '#content-cognitronchat'

const errorLoginString = 'You need to login to able to use the Chat!'

let errorString = 'An error occurred! Please try again later.';
let questionString = 'Ask a question...';
let usageError = "You have reached your chat limit this Month"
let botTitle = "Cognitron Chatbot"

const init = (Y, bot_name, question_placeholder, usage_error, human_feedback_enabled) => {

    document.querySelector(cognitronInputElementID).addEventListener('keyup', async e => {
        if (e.which === 13 && e.target.value !== "") {
            addToChatLog('user', e.target.value)

            // TODO Create Completion
            createCompletion(e.target.value);

            // Remove this simulation after
            // addToChatLog('bot loading', '...');
            // await sleep(2000);
            // let messageContainer = document.querySelector('#cognitron_chat_log')
            // messageContainer.removeChild(messageContainer.lastElementChild)
            // addToChatLog('bot', 'Hey My name is Mahara Tech Bot!');

            e.target.value = ''
        }
    })

    // Setting the error
    require(['core/str'], function (str) {
        let strings = [
            {
                key: 'erroroccurred',
                component: 'local_cognitron_recommender'
            },
        ];
        str.get_strings(strings).then((results) => {
            errorString = results[0];
        });
    });

    // Setting the bot title
    botTitle = bot_name;

    // Setting the question
    questionString = question_placeholder;

    // Setting the usage error message
    usageError = usage_error;
    humanFeedbackEnabled = human_feedback_enabled;
    //console.log(humanFeedbackEnabled);

}

const addToChatLog = (type, message) => {
    let messageContainer = document.querySelector(cognitronContentElementID);
    let feedbackIcons = '';

    if (type === 'bot' && humanFeedbackEnabled === '1') {
        feedbackIcons = `
            <div class='feedback-icons'>
				<a href="#feedback_modal">
					<span class='feedback-icon' onclick='openFeedbackModal(this, "up")'><i class='fa fa-thumbs-up' style="color:#FFFFFF"></i></span>
				</a>
				<a href="#feedback_modal">
					<span class='feedback-icon' onclick='openFeedbackModal(this, "down")'><i class='fa fa-thumbs-down' style="color:#FFFFFF"></i></span>
				</a>
            </div>			
        `;
    }

    messageContainer.insertAdjacentHTML('beforeend', `
        <div class='cognitron_message ${type}'>
            <div class='message-content'>
                ${message}
            </div>
            ${feedbackIcons}
        </div>
    `);
    messageContainer.scrollTop = messageContainer.scrollHeight;
}

// Function to open the feedback modal
const openFeedbackModal = (element, feedbackType) => {
    const modalContainer = document.createElement('div');
    modalContainer.classList.add('modal_feedback');
    modalContainer.setAttribute('data-feedback-type', feedbackType);
    modalContainer.id = "feedback_modal";

    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalContent.id = "feedback_modal_content";

    const closeBtn = document.createElement('span');
    closeBtn.classList.add('close');
    closeBtn.innerHTML = '&times;';
    closeBtn.id = 'close';
    closeBtn.addEventListener('click', closeFeedbackModal);

    const modalTitle = document.createElement('h2');
    modalTitle.textContent = 'Feedback';

    const feedbackTextarea = document.createElement('textarea');
    feedbackTextarea.setAttribute('rows', '4');
    feedbackTextarea.setAttribute('placeholder', 'Enter your feedback');

    // Get the parent message container
    const messageContainer = element.closest('.cognitron_message');
    // Get the prompt ID from the message content
    const messageContent = messageContainer.querySelector('.message-content');
    const promptID = messageContent.getAttribute('prompt-id');
    console.log(promptID);
    const submitBtn = document.createElement('button');
    submitBtn.textContent = 'Submit';
    submitBtn.id = 'submit_feedback';
    submitBtn.addEventListener('click', () => submitFeedback(promptID));


    modalContent.appendChild(modalTitle);
    modalContent.appendChild(feedbackTextarea);
    modalContent.appendChild(submitBtn);
    modalContent.appendChild(closeBtn);
    modalContainer.appendChild(modalContent);

    document.body.appendChild(modalContainer);
};

// Function to close the feedback modal
const closeFeedbackModal = () => {
    const modalContainer = document.querySelector('#feedback_modal');
    if (modalContainer) {
        document.body.removeChild(modalContainer);
    }
};

const sendFeedback = (promptID, feedbackType, feedbackMessage) => {
    // Replace the URL below with the API endpoint for logging user feedback
    const feedbackEndpoint = `${M.cfg.wwwroot}/local/cognitronchat/api/log_feedback.php`;
    console.log("Calling the feedbakc api.....");

    // Retrieve the last chat message
    //const messageContainer = document.querySelector(cognitronContentElementID);
    //const lastMessage = messageContainer.lastElementChild;

    // Extract the message text
    //let messageContent = lastMessage.querySelector('.message-content');
    //const messageText = messageContent.innerText;

    let like = false;
    let dislike = false;
    if (feedbackType === 'up') {
        like = true;
    }
    if (feedbackType === 'down') {
        dislike = true;
    }

    // Send the parameters to the API using fetch
    fetch(feedbackEndpoint, {
        method: 'POST',
        body: JSON.stringify({
            like: like,
            dislike: dislike,
            prompt: promptID,
            comment: feedbackMessage
        })
    })
        .then(response => {
            if (response.status === 401) {
                console.log(response.json());
                throw Error(response.statusText);
            } else if (response.status === 412) {
                console.log(response.json());
                alert("Your Feedback had been modified");
            }
            else if (!response.ok) {
                console.log(response.json());
                throw Error(response.statusText);
            } else {
                return response.json();
            }
        })
        .then(data => {
            console.log(data);
        })
        .catch(error => {
            document.querySelector(cognitronInputElementID).classList.add('disabled');
            document.querySelector(cognitronInputElementID).classList.add('error');
            document.querySelector(cognitronInputElementID).placeholder = errorLoginString;
        });
};

// Function to handle the submit button click event
const submitFeedback = (promptID) => {
    let modalContainer = document.querySelector('#feedback_modal');
    // Get the feedback type from the modal's data attribute
    const feedbackType = modalContainer.getAttribute('data-feedback-type');

    // Get the feedback message from the textarea
    //const feedbackMessage = "Feedback";//feedbackText.value;
    // Get the feedback message from the textarea
    const feedbackTextarea = document.querySelector('#feedback_modal_content textarea');
    const feedbackMessage = feedbackTextarea.value;

    sendFeedback(promptID, feedbackType, feedbackMessage);

    // Close the modal
    closeFeedbackModal();
};



const editLastMessageInChatlog = (prompt_id, new_message) => {
    let messageContainer = document.querySelector(cognitronContentElementID);
    let lastMessage = messageContainer.lastElementChild;
    let messageContent = lastMessage.querySelector('.message-content');
    new_message = new_message.replace(/\n/g, "<br>");
    messageContent.innerHTML = new_message;
    messageContent.setAttribute('prompt-id', prompt_id);
    messageContainer.scrollTop = messageContainer.scrollHeight;
}

const createCompletion = (message) => {
    /**
     * Makes an API request to get a cognitron response, and adds it to the chat log
     * @param {string} message The text to get a cognitron for
     */
    document.querySelector(cognitronInputElementID).classList.add('disabled');
    document.querySelector(cognitronInputElementID).classList.remove('error');
    document.querySelector(cognitronInputElementID).placeholder = questionString;
    document.querySelector(cognitronInputElementID).blur();
    addToChatLog('bot loading', '...');

    fetch(`${M.cfg.wwwroot}/local/cognitron_recommender/api/cognitron_response.php`, {
        method: 'POST',
        body: JSON.stringify({
            message: message,
        })
    })
        .then(response => {
            let messageContainer = document.querySelector(cognitronContentElementID);
            messageContainer.removeChild(messageContainer.lastElementChild);
            document.querySelector(cognitronInputElementID).classList.remove('disabled');

            addToChatLog('bot', '');

            // create a stream reader
            const reader = response.body.getReader();

            let output_response = "";
            let full_response = null;
            function processChunk(chunk) {
                const decoder = new TextDecoder();
                const text = decoder.decode(chunk, { stream: true });
                output_response += text;
                console.log("stream: ", output_response);

                full_response = output_response.split("_<PROMPT_SEP>_");
                console.log("prompt: ", full_response[0]);
                console.log("content: ", full_response[1]);
                editLastMessageInChatlog(full_response[0], full_response[1]);
            }

            function readChunks() {
                // read the next chunk from the stream
                reader.read().then(({ done, value }) => {
                    // if there's more data, process the chunk and keep reading
                    if (!done) {
                        processChunk(value);
                        readChunks();
                    } else {
                        console.log("Stream ended.");
                    }
                }).catch(error => {
                    console.error("Error occurred while streaming token data:", error);
                });
            }


            if (response.status === 401) {
                editLastMessageInChatlog(full_response[0], "Unauthorized Access, Please login then try again");
            } else if (response.status === 402) {
                editLastMessageInChatlog(full_response[0], usageError);
            } else if (response.status !== 200) {
                editLastMessageInChatlog(full_response[0], "We experience high load right now! Please try again later!");
            } else {
                // start reading chunks
                readChunks();
            }
        })
        .catch(error => {
            document.querySelector(cognitronInputElementID).classList.add('error');
            document.querySelector(cognitronInputElementID).placeholder = errorString;
        });

}



const registerUserToCognitron = () => {
    fetch(`${M.cfg.wwwroot}/local/cognitron_recommender/api/cognitron_token.php`, {
        method: 'POST',
        body: JSON.stringify({})
    })
        .then(response => {
            if (response.status === 401) {
                console.log(response.json());
                throw Error(response.statusText);
            } else if (!response.ok) {
                console.log(response.json());
                throw Error(response.statusText);
            } else {
                return response.json();
            }
        })
        .then(data => {
            console.log(data);
        })
        .catch(error => {
            document.querySelector(cognitronInputElementID).classList.add('disabled');
            document.querySelector(cognitronInputElementID).classList.add('error');
            document.querySelector(cognitronInputElementID).placeholder = errorLoginString;
        });
};

// Function to display a popup with recommended courses
const showRecommendationPopup = (recommendedCourses) => {
    // Create a container for the popup content
    const popupContainer = document.createElement('div');
    popupContainer.classList.add('recommendation-popup');

    // Add a title to the popup
    const title = document.createElement('h6');
    title.textContent = 'Recommended Courses:';
    popupContainer.appendChild(title);

    // Create a list to display the recommended courses
    const courseList = document.createElement('ul');

    // Populate the list with recommended courses
    recommendedCourses.forEach(course => {
        if (course.score >= 0.7) {
            const listItem = document.createElement('li');
            listItem.textContent = `${course.course} / ${course.score}`;
            courseList.appendChild(listItem);
        }
    });

    // Add the list to the popup
    popupContainer.appendChild(courseList);

    // Style the popup container
    popupContainer.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        border: 1px solid #ccc;
        padding: 10px;
        max-width: 300px;
        text-align: left;
        z-index: 9999;
    `;

    // Show the popup
    document.body.appendChild(popupContainer);
};


// set the recommendation api
const fetchRecommendation = () => {
    fetch(`${M.cfg.wwwroot}/local/cognitron_recommender/api/recommendation.php`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
    })
        .then(response => {
            if (response.status === 200) {

                return response.text();
            } else {
                throw new Error(`Unexpected response status: ${response.status}`);
            }
        })
        .then(data => {
            const jsonStartIndex = data.indexOf('{');
            const jsonData = JSON.parse(data.substring(jsonStartIndex));
            console.log('API Response:', jsonData);
            showRecommendationPopup(jsonData.recommended_courses);
        })
        .catch(error => {
            console.error('API Error:', error);
            alert("error", error)
        });
};


// Register the user to cognitron
registerUserToCognitron();
// Get Recommendation
fetchRecommendation();
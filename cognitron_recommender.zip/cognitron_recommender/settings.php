<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Plugin administration pages are defined here.
 *
 * @package     local_cognitron_recommender
 * @category    admin
 * @copyright   2023 Moamen Abdelrazek <moemen.abdelrazek@gmail.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_cognitron_recommender_settings', new lang_string('pluginname', 'local_cognitron_recommender'));

    // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedIf
    if ($ADMIN->fulltree) {
        $settings->add(new admin_setting_configcheckbox(
            'local_cognitron_recommender/enabled',
            get_string('enabled', 'local_cognitron_recommender'),
            get_string('enableddesc', 'local_cognitron_recommender'),
            1
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_cognitron_recommender/human_feedback_enabled',
            get_string('human_feedback_enabled', 'local_cognitron_recommender'),
            get_string('human_feedback_enabled_desc', 'local_cognitron_recommender'),
            1
        ));

        $settings->add(new admin_setting_configcheckbox(
            'local_cognitron_recommender/restrictusage',
            get_string('restrictusage', 'local_cognitron_recommender'),
            get_string('restrictusagedesc', 'local_cognitron_recommender'),
            1
        ));

        $settings->add(new admin_setting_configtext(
            'local_cognitron_recommender/host',
            get_string('host', 'local_cognitron_recommender'),
            get_string('hostdesc', 'local_cognitron_recommender'),
            '',
            PARAM_TEXT
        ));

        $settings->add(new admin_setting_configtext(
            'local_cognitron_recommender/apikey',
            get_string('apikey', 'local_cognitron_recommender'),
            get_string('apikeydesc', 'local_cognitron_recommender'),
            '',
            PARAM_TEXT
        ));

        $settings->add(new admin_setting_configtext(
            'local_cognitron_recommender/botID',
            get_string('botID', 'local_cognitron_recommender'),
            get_string('botIDdesc', 'local_cognitron_recommender'),
            '',
            PARAM_TEXT
        ));

        $settings->add(new admin_setting_configtext(
            'local_cognitron_recommender/botname',
            get_string('botname', 'local_cognitron_recommender'),
            get_string('botnamedesc', 'local_cognitron_recommender'),
            'Bot',
            PARAM_TEXT
        ));

        $settings->add(new admin_setting_configtext(
            'local_cognitron_recommender/usageerror',
            get_string('usageerror', 'local_cognitron_recommender'),
            get_string('usageerrordesc', 'local_cognitron_recommender'),
            'You have reached your chat limit this Month',
            PARAM_TEXT
        ));

        $settings->add(new admin_setting_configtext(
            'local_cognitron_recommender/askaquestion',
            get_string('askaquestion', 'local_cognitron_recommender'),
            get_string('askaquestiondesc', 'local_cognitron_recommender'),
            'Ask me any question!',
            PARAM_TEXT
        ));
    }

    $ADMIN->add('localplugins', $settings);
}

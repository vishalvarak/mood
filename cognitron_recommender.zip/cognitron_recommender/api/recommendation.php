<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Cognitron Chat response API is defined here.
 *
 * @package     local_cognitronchat
 * @copyright   2023 Mohamed Hany <Mohamed.hany182@outlook.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use \local_cognitronchat\cognitron;

ob_implicit_flush(true);
ini_set('zlib.output_compression', false);

require_once('../../../config.php');
require_once($CFG->libdir . '/filelib.php');

if (!isloggedin() or isguestuser($USER)) {
    echo "User is not logged in";
    header("HTTP/1.1 401 Unauthorized");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: $CFG->wwwroot");
    die();
}
$all_courses = get_courses();
if ($all_courses == 1) {
    echo "User on General Page";
    header("HTTP/1.1 404 NotFound");
    exit;
}
// $body = json_decode(file_get_contents('php://input'), true);
// if (json_last_error() !== JSON_ERROR_NONE) {
//     // Handle the JSON decoding error
//     header("HTTP/1.1 400 Bad Request");
//     echo "Invalid JSON data";
//     exit;
// }


// Get the user ID
$user_id = $USER->id;
// User enrolled courses
$enrolled_courses = enrol_get_users_courses($user_id);
// the original Host
$cognitronHost = get_config('local_cognitronchat', 'host');
// API URL
$apiUrl = $cognitronHost . '/api/chat';
// Global API Key
$apiKey = get_config('local_cognitronchat', 'apikey');
// Access Token
$accessToken = get_user_preferences(
    'cognitronAccessToken',
);

if (!$accessToken) {
    echo "This user doesn't have a valid token";
}
$all_rec = [
    'user_courses' => $enrolled_courses,
    "all_courses" => $all_courses,
];
$message = json_encode($all_rec);
$cognitronPayload = array(
    'message' => $message,
);
// Initialize a new cURL session
$curl = curl_init();

// Set the headers for the POST request
$headers = array(
    'Content-Type: application/json; charset=UTF-8',
    'X-API-KEY: ' . $apiKey,
    'Authorization: Bearer ' . $accessToken
);

// Set the cURL options
curl_setopt_array(
    $curl,
    array(
        CURLOPT_URL => $apiUrl,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($cognitronPayload, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 200,
        CURLOPT_HEADER => false,
        CURLOPT_WRITEFUNCTION => function ($curl, $data) {

            $response_code = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);

            // Only write data to stdout if the response code is 200
            if ($response_code == 200) {
                echo $data;
                flush();
                ob_flush();
            }

            return strlen($data);
        }
    )
);

// Execute the cURL request and handle the response
$cognitronResponse = curl_exec($curl);
$cognitronResponseCode = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);

if ($cognitronResponseCode === 401) {
    header("HTTP/1.1 401 Unauthorized");
} else if ($cognitronResponseCode === 402) {
    header("HTTP/1.1 402 UsageError");
} else if ($cognitronResponseCode !== 200) {
    header("HTTP/1.1 500 InternalServerError");
}


// Close the cURL session
curl_close($curl);



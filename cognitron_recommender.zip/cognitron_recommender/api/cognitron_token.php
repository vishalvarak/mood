<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Cognitron Chat token API is defined here.
 *
 * @package     local_cognitronchat
 * @copyright   2023 Moamen Abdelrazek <moemen.abdelrazek@gmail.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use \local_cognitronchat\cognitron;

require_once('../../../config.php');
require_once($CFG->libdir . '/filelib.php');

if (!isloggedin() or isguestuser($USER)) {
    echo "User is not logged in";
    header("HTTP/1.1 401 Unauthorized");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: $CFG->wwwroot");
    die();
}

$body = json_decode(file_get_contents('php://input'), true);

//$engine_class = '\local_cognitronchat\cognitron';
//$cognitron = new $engine_class($message);

// Get the currently logged-in user
$userid = $USER->id;

$cognitronHost = get_config('local_cognitronchat', 'host');

// API endpoint to request the access token
$requestTokenUrl = $cognitronHost.'/api/token/';

// API Key to use for authentication
$apiKey = get_config('local_cognitronchat', 'apikey');

// Bot Id
$botID = get_config('local_cognitronchat', 'botID');

// Set up the POST request with the API Key
// Initialize a new cURL session
$curl = curl_init();

// Set the headers for the POST request
$headers = array(
    'Content-Type: application/json; charset=UTF-8',
    'X-API-KEY: ' . $apiKey
);

$cognitronRequestTokenPayload = array(
    'user_id' => $userid,
    'bot_id' => $botID,
);

// Set the cURL options
curl_setopt_array($curl, array(
    CURLOPT_URL => $requestTokenUrl,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($cognitronRequestTokenPayload),
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => 'gzip, deflate',
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 120,
    CURLOPT_HEADER => false,
));

// Execute the request and get the response
$response = curl_exec($curl);

$info = curl_getinfo($curl);
$http_code = $info['http_code'];

if ($http_code != 200) {
    http_response_code($http_code);
    $response_data = array(
        'status' => 'failure',
        'message' => "This user doesn't have access to Mahara Tech Chatbot",
        'server_response' => $response,
    );
} else {
    // Decode the JSON response to extract the access token
    $data = json_decode($response, true);
    $accessToken = $data["access"];
    $refreshToken = $data["refresh"];

// Close the cURL session
    curl_close($curl);

// Set a custom property for the user
    $userUpdated = set_user_preference(
        'cognitronAccessToken',
        $accessToken,
    );

// Check for any errors
    if (!$userUpdated) {
        // Define your response data
        http_response_code(400);
        $response_data = array(
            'status' => 'failure',
            'userUpdatedPreferenceResponse' => $userUpdated,
            'message' => 'Access token successfully retrieved But cannot be saved to user in Moodle!',
        );
    }
    else {
        // Define your response data
        http_response_code(200);
        $response_data = array(
            'status' => 'success',
            'userUpdatedPreferenceResponse' => $userUpdated,
            'message' => 'Access token successfully retrieved and saved to user in Moodle!',
        );
    }
}
$json_response = json_encode($response_data);
header('Content-Type: application/json');
echo $json_response;




<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * The plugin is defined here.
 *
 * @package     local_cognitron_recommender
 * @copyright   2023 Moamen Abdelrazek <moemen.abdelrazek@gmail.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

function local_cognitron_recommender_before_standard_html_head()
{
    global $PAGE;
    $PAGE->requires->css('/local/cognitron_recommender/styles.css');
}

function local_cognitron_recommender_before_footer()
{
    global $USER, $CFG, $PAGE, $OUTPUT;

    $cognitronchatTemplateName = 'local_cognitron_recommender/cognitronchat';
    $cognitronchatEnabled = get_config('local_cognitron_recommender', 'enabled');

    $bot_name = get_config('local_cognitron_recommender', 'botname');
    $question_placeholder = get_config('local_cognitron_recommender', 'askaquestion');
    $usage_error = get_config('local_cognitron_recommender', 'usageerror');
    $human_feedback_enabled = get_config('local_cognitron_recommender', 'human_feedback_enabled');

    if ($cognitronchatEnabled) {
        $data = [
            'user_name' => $USER->firstname,
            'user_id' => $USER->id,
            'assistant_name' => 'Cognitron',
            'bot_name' => $bot_name,
            'question_placeholder' => $question_placeholder,
            'usage_error' => $usage_error,
        ];

        $PAGE->requires->js('/local/cognitron_recommender/lib.js');
        $PAGE->requires->js_init_call('init', [$bot_name, $question_placeholder, $usage_error, $human_feedback_enabled]);

        echo $OUTPUT->render_from_template($cognitronchatTemplateName, $data);
    }


}

